function About() {
  return (
    <div className="container">
      <h2>About Us</h2>
      <p>
        Welcome to Istiyak Service Point. Our mission is to provide all government and online services in one place for easy access and convenience.
      </p>
    </div>
  );
}
export default About;
